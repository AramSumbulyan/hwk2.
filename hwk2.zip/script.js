// //1.1
// if(numberExists(5 , 2463))
// console.log("Yes")
// else
// console.log("No")

// //1.2
// if (numberExists(4, 6))
// console.log("yes")
// else
// console.log("no")

// //1.3
// if (numberExists(8, 45689))
// console.log("yes")
// else
// console.log("no")

//2.1

// function reverse(num) 
// {
//   let newNum = ""
//   while (num !== 0)
// {
//     const lastDigit = num % 10
//     newNum += lastDigit
//     num = (num - lastDigit) / 10
// }
//   return Number(newNum)
// }  
// console.log(reverse(2))

//2.2

// function reverse(num) 
// {
//   let newNum = ""
//   while (num !== 0)
// {
//     const lastDigit = num % 10
//     newNum += lastDigit
//     num = (num - lastDigit) / 10
// }
//   return Number(newNum)
// }  
// console.log(reverse(13))


//2.3

// function reverse(num) 
// {
//   let newNum = ""
//   while (num !== 0)
// {
//     const lastDigit = num % 10
//     newNum += lastDigit
//     num = (num - lastDigit) / 10
// }
//   return Number(newNum)
// }  
// console.log(reverse(895796))

// //3.1
//   function FindMaxAndMin(num)
//   {
//     const strNum = "" + num
//     let min = 9
//     let max = 0
//     for (let i = 0; i < strNum.length; i++ )
//     {
//       const currentDigit = Number(strNum[i])
//       //console.log("currentDigit", currentDigit)
//       if ( currentDigit > max ) max = currentDigit
//       if ( currentDigit < min ) min = currentDigit
//     }
//     return max - min
//   }

//   console.log(FindMaxAndMin(5)) 

//   // 3.2

//   function FindMaxAndMin(num)
//   {
//     const strNum = "" + num
//     let min = 9
//     let max = 0
//     for (let i = 0; i < strNum.length; i++ )
//     {
//       const currentDigit = Number(strNum[i])
//       //console.log("currentDigit", currentDigit)
//       if ( currentDigit > max ) max = currentDigit
//       if ( currentDigit < min ) min = currentDigit
//     }
//     return max - min
//   }

//   console.log(FindMaxAndMin(152)) 
    
//   //3.3
//    function FindMaxAndMin(num)
//   {
//     const strNum = "" + num
//     let min = 9
//     let max = 0
//     for (let i = 0; i < strNum.length; i++ )
//     {
//       const currentDigit = Number(strNum[i])
//       //console.log("currentDigit", currentDigit)
//       if ( currentDigit > max ) max = currentDigit
//       if ( currentDigit < min ) min = currentDigit
//     }
//     return max - min
//   }

//   console.log(FindMaxAndMin(4593563)) 

//4.1.2
// function isPrime(num) {
//   if(num == 1)
//     return false;
//   if(num%2 == 0)
//   {
//     if(num == 2)
//       return true
//     return false
//   }
//   for(let i = 3; i*i < num; i++, i++)
//   {
//     if(num % i == 0)
//     {
//       return false
//     }
//   }
//   return true
// }

// console.log(isPrime(401))
// console.log(isPrime(63))
// 5.
// function rockPaperScissors()
// {
//   let Player1 = prompt("Enter your move")
//   Player1 = Player1.toLowerCase()
//   while(Player1 != "rock" && Player1 != "paper" && Player1 != "scissors")
//   {
//     console.log("Invalid move, please enter rock, paper or scissors")
//     let Player1 = prompt("Enter your move")
//   }
//   console.log("Player 1 plays: " + Player1)

//   let Player2 = prompt("Enter your move")
//   Player2 = Player2.toLowerCase()
//   while(Player2 != "rock" && Player2 != "paper" && Player2 != "scissors")
//   {
//     console.log("Invalid move, please enter rock, paper or scissors")
//     let Player2 = prompt("Enter your move")
//   }
//   console.log("Player 1 plays: " + Player2)

//   switch(Player1)
//   {
//     case "rock":
//       switch(Player2)
//       {
//         case "rock":
//           rockPaperScissors()
//           break;
//         case "paper":
//           console.log("Player 2 wins!!!")
//           break;
//         case "scissors":
//           console.log("Player 1 wins!!!")
//           break;
//       }
//       break;
//     case "paper":
//       switch(Player2)
//       {
//         case "paper":
//           rockPaperScissors()
//           break;
//         case "scissors":
//           console.log("Player 2 wins!!!")
//           break;
//         case "rock":
//           console.log("Player 1 wins!!!")
//           break;
//       }
//       break;
//     case "scissors":
//       switch(Player2)
//       {
//         case "scissors":
//           rockPaperScissors()
//           break;
//         case "rock":
//           console.log("Player 2 wins!!!")
//           break;
//         case "paper":
//           console.log("Player 1 wins!!!")
//           break;
//       }
//       break;
//   }
// }

// rockPaperScissors()

// 6.1.2.3.4

// function fibonacciNumber (num) {
//   if (num === 0)
//        return 0;
//   if (num === 1 || num === 2)
//        return 1;
//   let  a = 1, b = 1, current; 
//   for(let i = 3; i <= num; i++) {
//       current = a + b;
//       a = b;
//       b = current;
//   }
//   return current;
// }
// console.log(fibonacciNumber(0))
// console.log(fibonacciNumber(2))
// console.log(fibonacciNumber(10))
// console.log(fibonacciNumber(20))


// 7.1.2
// function fibonacciNumber (num) {
//   let  a = 1, b = 1, current; 
//   for(let i = 3; i <= num; i++) {
//       current = a + b;
//       a = b;
//       b = current;
//   return (i);
//   }
// }

// console.log(fibonacciNumber(7))
// console.log(fibonacciNumber(45))


//  8. 
// function calcSequence (n)
// {
//   result = 0
//   for (let i = 0; i < n; i++) 
//   {  
//      result += Math.pow(-1, i) * 1/(2*i + 1)
//   } 
//   return result
// } 
// console.log (calcSequence (1))

// 9. 
// function comb ()
// {
//   for(let i=0; i< 10; i++) 
//   { 
//     for(let j=0; j< 10; j++) 
//     { 
//       console.log("" + i + j) 
//     }
//   }
// }

// comb()
//   10.1.2.3.4

//   function productNum (number) {
//     let figures = "" + number
//     let product = 1;
//       for (let i = 0; i < figures.length; i++) 
//        product *= +figures[i]
//       return product
// }



//    function sumNum (number) {
//     let figures = "" + number
//     let sum = 0
//       for (let i = 0; i < figures.length; i++) 
//        sum += +figures[i]
//       return sum
// }

// function myFunc(number)
// {
//   sum = sumNum(number)
//   prod = productNum(number)
//   if(sum == 0)
//   {
//     console.log("Can't evaluate")
//     return
//   }
//   if (prod%sum==0) 
//   {
//     const quotient = prod/sum
//     console.log (`quotient is ${quotient}`)
//   } else { 
//     const remainder = prod%sum;
//     console.log (`remainder is ${remainder}`)
//   }
// }

// myFunc(1233)
// myFunc(5)
// myFunc(0)
// myFunc(445)
